		<div id="tables">
			<table>
				<caption>Tabla por defecto</caption>
				<thead>
					<tr>
						<th>Texto</th>
						<th>Párrafo</th>
						<th class="ar">Telefono</th>
						<th class="ar">Numero</th>
						<th class="ar">Decimales</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Departamento de Maquetación</td>
						<td class="p40">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel nulla ut libero luctus blandit eget sed sapien! Pellentesque non dui non quam placerat adipiscing id ut sapien.</p>
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">2587</td>
						<td class="float">51825.7558</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Ventas</td>
						<td class="p40">							
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">87955</td>
						<td class="float">0.7</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Marketing</td>
						<td class="p40">							
							<p>Diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">12</td>
						<td class="float">875.254984646</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Desarrollo</td>
						<td class="p40">							
							<p class="substring_50">Ejemplo con CADENA CORTADA A 50 CARACTERES. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">98531</td>
						<td class="float">513354.12313213213</td>
						<td class="actions">Acciones</td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="6">pie</td>
					</tr>
				</tfoot>				
			</table>
			<div>
				<h2>Normas sobre Tablas</h2>
				<ul>
					<li>Hay varios tipos de celdas: <code> phone, number, float, actions</code>. Cada una tiene unas caracteristicas propias</li>
					<li>Las celdas de tabla que tengan la clase <code>number</code> ó <code>float</code> serán formateadas y alineadas a a la derecha</li>
					<li>Las celdas que tengan textos largos deberán estar dentro de las etiquetas de parrafo <code>&lt;p&gt;...&lt;/p&gt;</code></li>
					<li>
						<p>Si queremos cortar un texto a un determinado número de caracteres tendremos que añadirle la case <code>substring_X</code> (siendo X el número de caracteres deseado). Esto, a parte de cortar la cadena, generará un tooltip con la cadena completa.</p>
					</li>
				</ul>
			</div>
			
			<h2>Tabla dinámica</h2>
			<p>Es una tabla normal, pero aprovecha la funcionalida del plugin de <a href="http://www.datatables.net/">jQuery DataTables</a> para poder ordenar, paginar (en cliente o vía ajax), ... Para usarla hay que insertar el siguiente código</p>
			<pre>
				$(document).ready(function(){
					&nbsp;&nbsp;$('#example').dataTable();
				});
			</pre>
			<script>
				$(document).ready(function(){
					$('.dataTable').dataTable();
				});
			</script>
			<table class="dataTable">
				<thead>
					<tr>
						<th>Texto</th>
						<th>Párrafo</th>
						<th class="ar">Telefono</th>
						<th class="ar">Numero</th>
						<th class="ar">Decimales</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Departamento de Maquetación</td>
						<td class="p40">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel nulla ut libero luctus blandit eget sed sapien! Pellentesque non dui non quam placerat adipiscing id ut sapien.</p>
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">2587</td>
						<td class="float">51825.7558</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Ventas</td>
						<td class="p40">							
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">87955</td>
						<td class="float">0.7</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Marketing</td>
						<td class="p40">							
							<p>Diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">12</td>
						<td class="float">875.254984646</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Desarrollo</td>
						<td class="p40">							
							<p class="substring_50">Ejemplo con CADENA CORTADA A 50 CARACTERES. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">98531</td>
						<td class="float">513354.12313213213</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Maquetación</td>
						<td class="p40">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel nulla ut libero luctus blandit eget sed sapien! Pellentesque non dui non quam placerat adipiscing id ut sapien.</p>
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">2587</td>
						<td class="float">51825.7558</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Ventas</td>
						<td class="p40">							
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">87955</td>
						<td class="float">0.7</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Marketing</td>
						<td class="p40">							
							<p>Diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">12</td>
						<td class="float">875.254984646</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Desarrollo</td>
						<td class="p40">							
							<p class="substring_50">Ejemplo con CADENA CORTADA A 50 CARACTERES. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">98531</td>
						<td class="float">513354.12313213213</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Maquetación</td>
						<td class="p40">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel nulla ut libero luctus blandit eget sed sapien! Pellentesque non dui non quam placerat adipiscing id ut sapien.</p>
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">2587</td>
						<td class="float">51825.7558</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Ventas</td>
						<td class="p40">							
							<p>Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">87955</td>
						<td class="float">0.7</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Marketing</td>
						<td class="p40">							
							<p>Diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">12</td>
						<td class="float">875.254984646</td>
						<td class="actions">Acciones</td>
					</tr>
					<tr>
						<td>Departamento de Desarrollo</td>
						<td class="p40">							
							<p class="substring_50">Ejemplo con CADENA CORTADA A 50 CARACTERES. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque venenatis diam non nunc fermentum ut rutrum tellus imperdiet! </p>
						</td>
						<td class="phone">696 123 321</td>
						<td class="number">98531</td>
						<td class="float">513354.12313213213</td>
						<td class="actions">Acciones</td>
					</tr>
				</tbody>		
			</table>
		</div>