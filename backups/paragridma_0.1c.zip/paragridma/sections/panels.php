		<div id="panels">
			
			<h2>Paneles Genéricos</h2>
			<div class="p50">
				<h4>Panel por defecto</h4>
				<p class="nm">Para crear un panel añadiremos la clase "p" al elemento</p>
				<div class="p">
					Esto es un panel por defecto
				</div>
			</div>
			<div class="p50">
				<h4>Panel por defecto con border</h4>
				<p class="nm">Para crear un panel añadiremos la clase <code>p</code> y la clase <code>b</code>al elemento</p>
				<div class="p b">
					Esto es un panel CON BORDE por defecto
				</div>
			</div>
			<h2>Toggle Panels</h2>
			<p>Ejemplo de un panel que se muestra al hacer clic en un objeto:</p>
			<pre>
				&lt;a href="#togglePanel" class="toggle_trigger" rel="Mostrar|Ocultar"&gt;<br/>
				&nbsp;&nbsp;Mostrar panel<br/>
				&lt;/a&gt;<br/>
				&lt;div id="togglePanel" class="p hidden"&gt;<br/>
				&nbsp;&nbsp;Panel oculto<br/>
				&lt;/div&gt;
			</pre>
				Tiene 2 partes:
					<ul>
						<li>El link que hace abrir el panel, que debe tener la clase <code>toggle_trigger</code></li>
						<li>El propio panel. Si queremos que aparezca oculto por defecto debe tener la clase <code>hidden</code>. Si no la ponemos el panel estará visible por defecto</li>
					</ul>
				<p>
				El link debe de tener 3 atributos:
				<ul>
					<li>La clase <code>toggle_trigger</code></li>
					<li>El atributo <code>href</code> con el identificador del panel</li>
					<li>El atributo <code>rel</code> con 2 cadenas de texto separados por el caracter <code>"|"</code>:
						<ul>
							<li>La primera el texto a mostrar cuando el panel está oculto</li>
							<li>La segunda el texto a mostrar cuando el panel está visible</li>
						</ul>
					</li>
				</ul>
				</p>
			<div class="p p45">
				<a href="#togglePanel" class="toggle_trigger bt" rel="Mostrar|Ocultar">Mostrar panel que está OCULTO por defecto</a>
				
				<div id="togglePanel" class="p hidden">
					Panel oculto por defecto que se puede mostrar
				</div>
			</div>
			<div class="p p45 fr">
				<a href="#togglePanel2" class="toggle_trigger bt" rel="Mostrar|Ocultar">Ocultar panel que está VISIBLE por defecto</a>
				
				<div id="togglePanel2" class="p">
					Panel visible por defecto que se puede ocultar
				</div>
			</div>
			<div class="sep"></div>
			
			<h2>Ventanas modales</h2>
			<p>Usamos el plugin de jQuery <a href="http://www.pierrebertet.net/projects/jquery_superbox/" target="_blank">Dialog</a>, ya que es muy ligero, accesible y extensible.</p>
			Normas de uso:
			<ul>
				<li>Debemos de tener un link que lanzará dicha ventana modal.
				</li>
				<li>Este link tiene que tener la etiqueta <code>rel=modal[content]</code>, así como un <code>id="link_id"</code> y <code>href="modal_win_id or URL"</code>.
				</li>
				<li>Dependencias:
					<ul>
						<li>jQuery</li>
						<li>jQuery UI
							<ul>
								<li>UI Core</li>
								<li>UI Position</li>
								<li>UI Widget</li>
								<li>UI Mouse (opcional)</li>
								<li>UI Dragable (opcional)</li>
								<li>UI Resizable (opcional)</li>
							</ul>
						</li>
						<li>modal.js</li>
					</ul>
				</li>
				<li>Settings:</li>
				<pre>
					autoOpen: false, // hidden by default
					draggable: false,
					resizable: false,
					show: 'slide', // The effect to be used when the dialog is opened
					hide: 'slide', // The effect to be used when the dialog is closed.
					
					height: 530,
					maxHeight: 400,
					minHeight: 300,
					
					width: 460,
					minWidth: 400,
					maxWidth: 600,
					
					position: 'top', //'center', 'left', 'right', 'top', 'bottom', ['right','top']
					closeOnEscape: false, // default: true
					dialogClass: 'alert',
					buttons: { ... }
				</pre>
			</ul>
			<h3>Contenido en Línea</h3>
			<a id="modal_test" href="#modal_demo_A" rel="modal[content][200x150]" class="bt">Ejemplo de Modo en línea</a>
		
			<div id="modal_demo_A" title="hola222!!!!" class="modal hidden">
				<p>INLINE CONTENT: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vitae diam ac purus dignissim malesuada et ut est. Donec pretium accumsan metus, eget molestie enim pharetra non. Proin suscipit lacus et libero consequat ac convallis diam ullamcorper. Fusce luctus eleifend tempus. Nulla vehicula posuere iaculis. Suspendisse elementum orci non nisi tempus sollicitudin vehicula nibh tempor. Donec mattis dictum risus vitae rutrum.</p>
			</div>
			<pre>
				&lt;a id="modal_test" href="#modal_demo_A" rel="modal[content][200x150]" class="bt">Ejemplo de Modo en línea</a>
				
				&lt;div id="modal_demo_A" title="title of the window" class="modal hidden">&lt;/div>
			</pre>
			
			<h3>Contenido cargado por Ajax</h3>
			<a id="modal_ajax_test" href="sections/ajax_content.html" title="Modal Window Title" rel="modal[content][300x150]" class="bt">Ejemplo de Modo AJAX</a>
			<pre>
				&lt;a id="modal_ajax_test" href="sections/ajax_content.html" title="Modal Window Title" rel="modal[content][300x150]" class="bt">Ejemplo de Modo AJAX&lt;/a>
			</pre>
			
			<h3>Contenido cargado en IFRAME (PENDIENTE)</h3>
			<a id="modal_iframe_test" href="sections/ajax_content.html" title="Modal Window Title" rel="modal[iframe][400x150]" class="bt">Ejemplo de Modo IFRAME</a>
			<pre>
				&lt;a id="modal_iframe_test" href="sections/ajax_content.html" title="Modal Window Title" rel="modal[iframe][400x150]" class="bt">Ejemplo de Modo IFRAME&lt;/a>
			</pre>
			
		</div>