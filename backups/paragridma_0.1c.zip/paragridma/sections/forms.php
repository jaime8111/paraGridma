		<div id="forms">
			<h2>Ejemplos de Formularios</h2>
			<p>A continuación mostraremos ejemplos de formularios.</p>
			<p>Cada componente de formulario (por ejemplo: label + input) irá dentro de un div con clase: <strong>fg</strong></p>			
			<div class="col3">
				<div class="col">				
					<form class="p">
						<h3>XFormularios HORIZONTALES</h3>
						
						<div class="fg">
							<label for="">Label</label>
							<input type="text" value="valor del input"/>
						</div>
						
						<div class="fg">
							<label for="">Label</label>
							<select>
								<option>option</option>
							</select>
						</div>
						<div class="fg">
							<label for="">Label</label>
							<textarea>Esto es un textarea</textarea>
						</div>
						<div class="fg checkboxGroup">
							<label for="">Label</label>
							<input type="checkbox" class="checkbox" value="valor del input"/>
						</div>
						<div class="fg radioGroup">
							<label>Label</label>
							<div class="options">
								<div class="option">
									<input type="radio" class="radio"  name="name" value=""/>
									<label for="">option 1</label>								
								</div>
								<div class="option">
									<input type="radio" class="radio"  name="name" value=""/>
									<label for="">option 2</label>	
								</div>
								<div class="option">
									<input type="radio" class="radio"  name="name" value=""/>
									<label for="">option 3</label>
								</div>
							</div>
						</div>
						<span>Estructura input tipo texto:</span>
						<pre>&lt;div class="fg"&gt;
						&nbsp;&nbsp;&lt;label for="inputID"&gt;Label&lt;/label&gt;
						&nbsp;&nbsp;&lt;input type="text"/&gt;
						&lt;/div&gt;</pre> 
						<span>Estructura input tipo CHECKBOX:</span>
						<pre>&lt;div class=&quot;fg checkboxGroup&quot;&gt;
						&nbsp;&nbsp;&lt;label for=&quot;&quot;&gt;Label&lt;/label&gt;
						&nbsp;&nbsp;&lt;input type=&quot;checkbox&quot; class=&quot;checkbox&quot; value=&quot;&quot;/&gt;
						&lt;/div&gt;</pre> 
						<span>Estructura input tipo RADIO:</span>
						<pre>&lt;div class="fg radioGroup"&gt;<br />&nbsp;&nbsp;&lt;label&gt;Label&lt;/label&gt;<br />&nbsp;&nbsp;&lt;div class=&quot;options&quot;&gt;<br />&nbsp;&nbsp;&nbsp;&nbsp;&lt;input type=&quot;radio&quot; class=&quot;radio&quot;  name=&quot;name&quot;/&gt;<br />&nbsp;&nbsp;&nbsp;&nbsp;&lt;label for=&quot;&quot;&gt;option 1&lt;/label&gt;	<br />&nbsp;&nbsp;&nbsp;&nbsp;&lt;input type=&quot;radio&quot; class=&quot;radio&quot;  name=&quot;name&quot; value=&quot;&quot;/&gt;<br />&nbsp;&nbsp;&nbsp;&nbsp;&lt;label for=&quot;&quot;&gt;option 2&lt;/label&gt;&nbsp;&nbsp;&lt;/div&gt;<br />&lt;/div&gt;
						</pre>
					</form>
				</div>
				<div class="col">
					<form class="fv p">
						<h3>Formularios VERTICAL</h3>					
						<div class="fg">
							<label for="">Label</label>
							<input type="text" value="valor del input"/>
						</div>
						<div class="fg">
							<label for="">Label</label>
							<select>
								<option>ancho de 2 columnas</option>
							</select>
						</div>
						<div class="fg">
							<label for="">Label</label>
							<textarea>Esto es un textarea</textarea>
						</div>
						<div class="fg checkboxGroup">
							<label for="">Label</label>
							<input type="checkbox" class="checkbox" value="valor del input"/>
						</div>
						<div class="fg radioGroup">
							<label>Label</label>
							<div class="options">	
								<div class="option">
									<input type="radio" class="radio"  name="name" value="valor del input"/>
									<label for="">option 1</label>	
								</div>
								<div class="option">
									<input type="radio" class="radio"  name="name" value="valor del input"/>
									<label for="">option 2</label>		
								</div>
								<div class="option">
									<input type="radio" class="radio"  name="name" value="valor del input"/>
									<label for="">option 3</label>
								</div>
							</div>
						</div>
						<p>Si queremos que el formulario se vision de "forma vertical" (el label encima del input) basta con añadir la case <code>fv</code> al formuario</p>
						<pre>
							&lt;form class="fv"&gt;
							&nbsp;&nbsp;...
							&lt;/form&gt;
						</pre>
					</form>
				</div>
				<div class="col">				
					<form class="label_w1 input_w2 p">
						<h3>Formularios y ANCHURAS</h3>						
						<div class="fg">
							<label for="">Label</label>
							<input type="text" value="valor del input"/>
						</div>
						<div class="fg">
							<label for="" class="label_w2">Label más largo</label>
							<input type="text" value="valor del input"  class="input_w1"/>
						</div>
						<div class="fg">
							<label for=""  class="label_w05">Label</label>
							<input type="text"  class="input_w15" value="valor del input"/>
						</div>	
						<p>la clase <code>label_w[05,1,15,2,...,6]</code> define la anchura de los labels</p>
						<p>la clase <code>input_w[05,1,15,2,...,6]</code> define la anchura de los inputs, selects y textarea</p>
						<p class="nm">Si añadimos estas clases en el "padre" definimos la anchura de todos sus "hijos".</p>
						<pre>
							&lt;form class="label_w1 input_w2"&gt;
							&nbsp;&nbsp;...
							&lt;/form&gt;
						</pre>
						<p class="nm">Puesto en el propio campo sobrescribe la anchura previamente definida.</p>
						<pre>
							&lt;label class="label_w2"/&gt;
							&lt;input class="input_w2"/&gt;
							&lt;select class="input_w2"/&gt;
							&lt;textarea class="input_w2"/&gt;
						</pre>
					</form>
				</div>				
				<div class="col">					
					<form class="label_w1 input_w2 p">
						<h3>Formularios con Ayudas</h3>
						<div class="fg">
							<label for="">Label</label>
							<input type="text" value="valor del input"/>
							<span class="fieldNote">Ayuda del input</span>
						</div>
						<div class="fg">
							<label for="">Label</label>
							<select>
								<option>ancho de 2 columnas</option>
							</select>
							<span class="fieldNote">Ayuda del select</span>
						</div>
						<div class="fg">
							<label for="">Label</label>
							<textarea>Esto es un textarea</textarea>
							<span class="fieldNote">Ayuda del textarea</span>
						</div>
						<p>
							La ayuda debe de ser un <code>&lt;span class="fieldNote"&gt;</code> situado justo despues del input.
						</p>
						<pre>&lt;span class="fieldNote"&gt;Ayuda del input&lt;/span&gt;</pre> 
						
					</form>
				</div>
				<div class="col">				
					<form class="p">
						<h3>Formularios con PLACEHOLDER</h3>
						
						<div class="fg">
							<label for="">Label</label>
							<input type="text" placeholder="placeholder"/>
						</div>
						<p>
							Para usarlo hay que poner el atributo <code>placeholder=""</code> al input.
						</p>
						<pre>&lt;input placeholder=""&gt;</pre> 
					</form>
					<form class="p">
						<h3>Formularios con DATEPICKER</h3>
						<script>
							$(function(){
								//if (!Modernizr.inputtypes.date) {
									$("input.date").datepicker({ 
										showOn: 'both',
										dateFormat: 'dd-mm-yy'
									});
								//}
							})
						</script>
						
						<div class="fg">
							<label for="">Label</label>
							<input type="date" class="date"/>
						</div>
						<p>Para usarlo hay que poner el atributo <code>type="date"</code> y <code>class="date"</code>(para que funcione en IE6) al input.
						</p>
						<pre>&lt;input type="date"&gt;</pre> 
						<p><a href="http://docs.jquery.com/UI/Datepicker" target="_blank">Ayuda del componente jQuery</a> 
						</p>
					</form>
				</div>
				<div class="col">				
					<form class="p">
						<h3>Formularios con AUTOFOCUS</h3>
						<div class="fg">
							<label for="">Label</label>
							<input type="text" autofocus/>
						</div>
						<p>
							Para usarlo hay que poner el atributo <code>autofocus</code> al input.
						</p>
						<pre>&lt;input autofocus&gt;</pre> 
						<p>Si hubiera varios input con dicho atributo en la misma pagina, el cursor se situaría en el último de ellos. En esta versión el autofocus no funciona para IE7
						</p>
						
					</form>
				</div>

			</div>
			<div class="p cb">
				<h3>Formularios VERTICAL 3 COLUMNAS</h3>
				<form class="fv col3">
					<div class="fg col">
						<label for="">Label</label>
						<input type="text" value="valor del input"/>
					</div>
					<div class="fg col">
						<label for="">Label</label>
						<input type="text" value="ancho de 2 columnas"/>
					</div>
					<div class="fg col">
						<label for="">Label</label>
						<select>
							<option>ancho de 2 columnas</option>
						</select>
					</div>
					<div class="fg col">
						<label for="">Label</label>
						<select>
							<option>opción</option>
						</select>
					</div>
					<div class="fg col">
						<label for="">Label</label>
						<textarea>Esto es un textarea</textarea>
					</div>
					<div class="col">
						<p>Para conseguir este efecto de 3 columnas hay que usar este código:
						</p>
						<pre>&lt;form class="fv <strong>col3</strong>"&gt;
						&nbsp;&nbsp;&lt;div class="col"&gt; ... &lt;/div&gt;
						&nbsp;&nbsp;&lt;div class="col"&gt; ... &lt;/div&gt;
						&nbsp;&nbsp;&lt;div class="col"&gt; ... &lt;/div&gt;
						&lt;form&gt;</pre> 
						<p>
							Las columnas (marcadas con la clase <code>col</code>) deben estar dentro de una etiqueta con la clase <code>col3</code>.
						<p>
					</div>	
				</form>
			</div>
			<h3>Botones</h3>
			<div class="col3">				
				<div class="col">
					<h4>Boton de LINK por defecto + Botón secundario</h4>
					<a href="javascript:void(0)" class="bt"><span>Botón</span></a>
					<a href="javascript:void(0)" class="bt bt_sub"><span>Botón Secundario</span></a>
					<pre>
						&lt;class="bt"&gt;&lt;span&gt;texto&lt;/span&gt;&lt;/a&gt;
						&lt;class="bt bt_sub"&gt;&lt;span&gt;texto&lt;/span&gt;&lt;/a&gt;
					</pre>
				</div>
				<div class="col">
					<h4>Boton de LINK por defecto + Botón tipo TEXTO</h4>
					<a href="javascript:void(0)" class="bt"><span>Botón</span></a>
					<a href="javascript:void(0)" class="bt bt_text"><span>Botón Secundario</span></a>
					<pre>
						&lt;class="bt"&gt;&lt;span&gt;texto&lt;/span&gt;&lt;/a&gt;
						&lt;class="bt bt_text"&gt;&lt;span&gt;texto&lt;/span&gt;&lt;/a&gt;
					</pre>
				</div>
				<div class="col">
					<h4>Boton de INPUT por defecto</h4>
					
					<span class="bt_input">
						<input type="button" class="bt" value="Botón INPUT"/>
					</span>
					
					<pre>
						&lt;span class="bt_input"&gt;&lt;input type="button" class="bt" value="texto"/&gt&lt;span&gt;;
					</pre>
				</div>
			</div>
		</div>