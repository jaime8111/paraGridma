		<div id="source">
			<h2>Fuentes</h2>
			<p>Para que este framework sea posible nos hemos inspirado en otros frameworks como <a href="http://www.webdesignerwall.com/tutorials/the-simpler-css-grid/" target="_blank">The simpler CSS Grid</a> ó <a href="http://www.frontendmatters.com/projects/fem-css-framework/" target="_blank">FEM CSS Framework</a>.</p>
			Tambien hemos incorporado varios plugins Javascript para añadir funcionalidad:
			<ul>
				<li><a href="http://jquery.com/" target="_blank">jQuery</a></li>
				<li><a href="http://jqueryui.com/" target="_blank">jQuery UI</a></li>
				<li><a href="http://www.modernizr.com/" target="_blank">Modernizr</a></li>
				<li><a href="" target="_blank">Librerias jQuery</a>
					<ul>
						<li><a href="http://plugins.jquery.com/project/currencynumberformatter" target="_blank">number Format</a></li>
						<li><a href="http://plugins.jquery.com/project/better-placeholder" target="_blank">Placeholder</a></li>
						<li><a href="http://www.datatables.net/" target="_blank">DataTable</a></li>
						<li>Ventana Modal: <strike><a href="http://www.pierrebertet.net/projects/jquery_superbox/" target="_blank">SuperBox</a></strike> jQuery Dialog</li>
						<li><a href="http://remysharp.com/2009/01/07/html5-enabling-script/" target="_blank">HTML 5 for IE</a></li>

					</ul>
				</li>

			</ul>

		</div>