<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>ParaGRIDma</title>
	<link rel="shortcut icon" href="img/favicon.ico" />

	<link rel="stylesheet" href="css/paragridma.css" type="text/css" media="all"/>
	
	<!-- CSS solo para la demo -->
	<link rel="stylesheet" href="css/base_dev.css" type="text/css" media="all" /> 
	
	
	<script type="text/javascript" src="js/packs/jquery.js"></script>
	
	<script>
		if($.browser.webkit) {
		
		} else if($.browser.opera) {
			document.write('<link rel="stylesheet" href="css/browser_opera.css" type="text/css" media="all"/>');
		} 
	</script>
	
	<script type="text/javascript" src="js/packs/jquery-ui.js"></script>
	<script type="text/javascript" src="js/packs/modernizr-1.6.min.js"></script>
	
	
	<!-- LIBRARIES -->
	<script src="js/packs/jquery.number_format.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/packs/jquery.placeholder.js"></script>
	<script type="text/javascript" src="js/packs/autofocus.js"></script>
	<script type="text/javascript" src="js/packs/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="js/packs/modal.js"></script>
	<script type="text/javascript" src="js/packs/jquery.log.js"></script>
	
	<script type="text/javascript" src="js/paragridma.js"></script>
	
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
	<![endif]-->
	<!--[if lte IE 7]>
		<link rel="stylesheet" href="css/browser_ie6_ie7.css" type="text/css" media="all"/>
	<![endif]-->
	<!--[if lte IE 6]>
		<link rel="stylesheet" href="css/browser_ie6.css" type="text/css" media="all"/>
		<script type="text/javascript" src="js/paragridma_ie6.js"></script>
	<![endif]-->
	<script>
		
		$(function(){
			//log("testing log function");
			//$.log("testing jquery log.", "Bob", 42);
			
		})
		
	</script>
</head>

<body>
<?php include("includes/visitor_info.html"); ?>
<div>
	<!-- ERROR MESSAGE -->
	<div class="msg msg_error pf pf_w1">
		<div class="pf_l"></div>
		<div class="pf_r">
		   <p class="title">No puedes acceder</p>
		   <p>El usuario o la contraseña no es válido.</p>
		</div>
	</div>
	<!-- INFO MESSAGE -->
	<div class="msg msg_info pf pf_w1">
		<div class="pf_l"></div>
		<div class="pf_r">
		   <p class="title">Test info message</p>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius sollicitudin pharetra.</p>
		</div>
	</div>
	<!-- SUCCESS MESSAGE -->
	<div class="msg msg_success pf pf_w1">
		<div class="pf_l"></div>
		<div class="pf_r">
		   <p class="title">Test success message</p>
		   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec varius sollicitudin pharetra.</p>
		</div>
	</div> 

</div>
<div class="push"></div> 
<footer>
		Ejemplo de Footer - ParaGRIDma&copy; 2010
</footer>
</body>
</html>
