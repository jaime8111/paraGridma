/* jQuery Modal Window */
$(function(){
	$("a[rel^=modal]").click(function(e){
		e.stopPropagation();
		e.preventDefault();
		
		var t = $(this);
		var relAttr = t.attr('rel');
		var link_id = t.attr('id');
		
		// Match type (ex : modal[content] or modal[iframe])
		attr = relAttr.match(/([^\[\]]+)/g);
		type = attr[1];
		dims = attr[2];
		
		if (type == 'iframe') {
			var href = t.attr('href');
			var w = ""; // target content
			var title = t.attr('title');
			
			// open content is an URL
			loadModalAjax(type, href, w, link_id, title);
			w =  $("#"+ link_id + "_modal");
		
		} else {
			var href = t.attr('href');
			var w = ""; // target content
			
			if (href.substr(0,1) == "#"){
				// href is an ID, so we open content of this div in dialog box
				w = $(href);
				if (!w.size()) { alert("panel " + href + " doesn't exist!"); }
				w.dialog( "option", "title", w.attr('title') );
			} else {
				// open content is an URL
				var title = t.attr('title');
				
				loadModalAjax(type, href, w, link_id, title);
				w =  $("#"+ link_id + "_modal");
			}
			
		}
		
		if(dims.length) { 
			// specific dimension
			dims = dims.split("x");
			if (dims[0] > 0) {		w.dialog( "option", "width", dims[0] );		}
			if (dims[1] > 0) {		w.dialog( "option", "height", dims[1] );	}
		}
		w.dialog('open');
	});
	$(".modal").dialog({ 
		autoOpen: false, // hidden by default
		draggable: false,
		resizable: false,
		//show: 'slide', // The effect to be used when the dialog is opened
		//hide: 'slide', // The effect to be used when the dialog is closed.
		
		//height: 530,
		//maxHeight: 400,
		//minHeight: 300,
		//width: 460,
		//minWidth: 400,
		//maxWidth: 600,
		//position: 'top', //'center', 'left', 'right', 'top', 'bottom', ['right','top']
		//closeOnEscape: false, // default: true
		//dialogClass: 'alert',
		/*
		buttons: { 
			"Ok": function() 
				{ $(this).dialog("close"); },
			"Cancel": function() 
				{ $(this).dialog("close"); } 
		}
		*/
		modal: true // The rest of items on the page will be disabled
	});
});

function loadModalAjax(type, href, w, link_id, title) {
	if (link_id == '') { alert('link must have an ID'); }
	if(!$("#"+ link_id + "_modal").size()) { // just create panel for the first time
		$('body').append('<div id="' + link_id + '_modal" title="'+title+'" class="modal '+ type +'"><span class="loading">loading...</span></div>');
		w =  $("#"+ link_id + "_modal");
		
		$.ajax({
		  url: href,
		  success: function(response){
			w.html(response);
		  },
		  error : function(){
			alert("ERROR: page " + href + "not reached.");
		  }
		});
		
		w.dialog({ 
			autoOpen: false,
			draggable: false,
			resizable: false,
			modal: true
		});
	}
}