$(function(){
	$("h2:first-child, h3:first-child, h4:first-child").each(function(){
		$(this).addClass('first-child');
	});

	$(".col3>.col:nth-child(3n+1)").each(function(){
		$(this).addClass('fourthCol').before('<div style="clear:both;height:0px; line-height:0;"></div>');
	});
	$(".col2>.col:nth-child(2n+1)").each(function(){
		$(this).addClass('thirdCol').before('<div style="clear:both;height:0px; line-height:0;"></div>');
	});
	
})