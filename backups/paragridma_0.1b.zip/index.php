<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>ParaGRIDma</title>
	<link rel="shortcut icon" href="img/favicon.ico" />

	<link rel="stylesheet" href="css/base.css" type="text/css" media="all"/>
	
	<!-- CSS solo para la demo -->
	<link rel="stylesheet" href="css/base_dev.css" type="text/css" media="all" /> 
	
	
	<script type="text/javascript" src="js/packs/jquery.js"></script>
	
	<script>
		if($.browser.webkit) {
		
		} else if($.browser.opera) {
			document.write('<link rel="stylesheet" href="css/browser_opera.css" type="text/css" media="all"/>');
		} 
	</script>
	
	<script type="text/javascript" src="js/packs/jquery-ui-1.8.6.custom.min.js"></script>
	<script type="text/javascript" src="js/packs/modernizr-1.6.min.js"></script>
	
	
	<!-- LIBRARIES -->
	<script src="js/packs/jquery.number_format.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/packs/jquery.placeholder.js"></script>
	<script type="text/javascript" src="js/packs/autofocus.js"></script>
	<script type="text/javascript" src="js/packs/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="js/packs/jquery.superbox.js"></script>
	<script type="text/javascript" src="js/packs/jquery.log.js"></script>
	
	<script type="text/javascript" src="js/paragridma.js"></script>
	
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
	<![endif]-->
	<!--[if lte IE 7]>
		<link rel="stylesheet" href="css/browser_ie6_ie7.css" type="text/css" media="all"/>
	<![endif]-->
	<!--[if lte IE 6]>
		<link rel="stylesheet" href="css/browser_ie6.css" type="text/css" media="all"/>
		<script type="text/javascript" src="js/paragridma_ie6.js"></script>
	<![endif]-->
	<script>
		
		$(function(){
			log("testing log function");
			$.log("testing jquery log.", "Bob", 42);
		})
		
	</script>
</head>

<body>

<div class="container fix">
	<header>
		<div id="logo" class="g3 first">
			<img src="img/paragridma.png" alt="paraGRIDma">
			<span id="version"><strong>beta 0.1</strong> - 01/06/2011</span>
		</div>
		<div id="claim" class="g9">
			<h1>Nuestro framework CSS + Javascript</h1>
			<p>La Base de nuestros proyectos</p>		
		</div>
	</header>
	
	<a id="showGuides" href="javascript:void(0)" class="bt bt_sub"><span>Mostrar GUÍAS</span></a>
	
	<div id="mainSections" class="tabs">
		<ul>
			<li><a href="#general"><span>General</span></a></li>
			<li><a href="sections/texts.php" title="texts"><span>Textos</span></a></li>
			<li><a href="sections/grids.php" title="grids"><span>Estructuras</span></a></li>
			<li><a href="#panels"><span>Paneles</span></a></li>
			<li><a href="#tables"><span>Tablas</span></a></li>
			<li><a href="#forms"><span>Formularios</span></a></li>
			<li><a href="sections/menu.php" title="menu"><span>Menu</span></a></li>
			<li><a href="sections/source.php" title="source"><span>Fuentes</span></a></li>
		</ul>
		<?PHP
			include("sections/general.php");
			
			include("sections/panels.php");
		
			include("sections/forms.php");
			include("sections/tables.php");
		?>
		
	</div>
</div>
<div class="push"></div> 
<footer>
		Ejemplo de Footer - ParaGRIDma&copy; 2010
</footer>
</body>
</html>
