		<div id="panels">
			<h2>Paneles Genéricos</h2>
			<div class="p50">
				<h4>Panel por defecto</h4>
				<p class="nm">Para crear un panel añadiremos la clase "p" al elemento</p>
				<div class="p">
					Esto es un panel por defecto
				</div>
			</div>
			<div class="p50">
				<h4>Panel por defecto con border</h4>
				<p class="nm">Para crear un panel añadiremos la clase <code>p</code> y la clase <code>b</code>al elemento</p>
				<div class="p b">
					Esto es un panel CON BORDE por defecto
				</div>
			</div>
			<h2>Toggle Panels</h2>
			<p>Ejemplo de un panel que se muestra al hacer clic en un objeto:</p>
			<pre>
				&lt;a href="#togglePanel" class="toggle_trigger" rel="Mostrar|Ocultar"&gt;<br/>
				&nbsp;&nbsp;Mostrar panel<br/>
				&lt;/a&gt;<br/>
				&lt;div id="togglePanel" class="p hidden"&gt;<br/>
				&nbsp;&nbsp;Panel oculto<br/>
				&lt;/div&gt;
			</pre>
				Tiene 2 partes:
					<ul>
						<li>El link que hace abrir el panel, que debe tener la clase <code>toggle_trigger</code></li>
						<li>El propio panel. Si queremos que aparezca oculto por defecto debe tener la clase <code>hidden</code>. Si no la ponemos el panel estará visible por defecto</li>
					</ul>
				<p>
				El link debe de tener 3 atributos:
				<ul>
					<li>La clase <code>toggle_trigger</code></li>
					<li>El atributo <code>href</code> con el identificador del panel</li>
					<li>El atributo <code>rel</code> con 2 cadenas de texto separados por el caracter <code>"|"</code>:
						<ul>
							<li>La primera el texto a mostrar cuando el panel está oculto</li>
							<li>La segunda el texto a mostrar cuando el panel está visible</li>
						</ul>
					</li>
				</ul>
				</p>
			<div class="p p45">
				<a href="#togglePanel" class="toggle_trigger bt" rel="Mostrar|Ocultar">Mostrar panel que está OCULTO por defecto</a>
				
				<div id="togglePanel" class="p hidden">
					Panel oculto por defecto que se puede mostrar
				</div>
			</div>
			<div class="p p45 fr">
				<a href="#togglePanel2" class="toggle_trigger bt" rel="Mostrar|Ocultar">Ocultar panel que está VISIBLE por defecto</a>
				
				<div id="togglePanel2" class="p">
					Panel visible por defecto que se puede ocultar
				</div>
			</div>
			<div class="sep"></div>
			<h2>Ventanas modales</h2>
			<p>Usamos el plugin de jQuery <a href="http://www.pierrebertet.net/projects/jquery_superbox/" target="_blank">Superbox</a>, ya que es muy ligero, accesible y extensible.</p>
			Normas de uso:
			<ul>
				<li>Es generado por el atributo rel de un link. Este atributo debe de contener la palabra superbox más el modo de vison. ejemplo: rel="superbox[display_mode]"
				</li>
				<li>Tambien puede ser asociado a un id o class del panel que se mostrará. Ejemplo: rel="superbox[type#my_id.my_class]"
				</li>
				<li>La ventana emergente es posicionada de modo <code>position:fixed</code> salvo que sea mayor que la ventana del navegador, en este caso usará <code>position:absolute</code> que permitirá al usuario ver el resto de la ventana usando las barras de scroll.
				</li>
				<li>Para activarla hay que escribir esto:</li>
				<pre>
					$(function(){
					&nbsp;	$.superbox();
					});
				</pre>
				<li>Los siguientes parametros pueden ser sobrescritos (estos son los valores por defecto):
				</li>
				<pre>
					$.superbox.settings = {	
					&nbsp;	boxId: "superbox", // Id attribute of the "superbox" element 
					&nbsp;	boxClasses: "", // Class of the "superbox" element
					&nbsp;	overlayOpacity: .8, // Background opaqueness
					&nbsp;	boxWidth: "600", // Default width of the box 
					&nbsp;	boxHeight: "400", // Default height of the box 
					&nbsp;	loadTxt: "Loading...", // Loading text
					&nbsp;	closeTxt: "Close", // "Close" button text 
					&nbsp;	prevTxt: "Previous", // "Previous" button text 
					&nbsp;	nextTxt: "Next" // "Next" button text
					};
				</pre>
			</ul>
			<h3>Modo Imágen</h3>
			<script>
				$(function(){
					$.superbox();
				});
			</script>
			<a href="http://farm1.static.flickr.com/27/45599281_0e33a17e35_z.jpg?zz=1" rel="superbox[image][x250]" class="bt">Ejemplo de Modo Imágen</a>
			<p>
			Por defecto:
			<pre>
				&lt;a href="http://example.com/picture.png" rel="superbox[image]">SuperBox&lt;/a&gt;
			</pre>
			Definiendo tamaño
			<pre>
				&lt;a href="http://example.com/picture.png" rel="superbox[image][500x200]"&gt;SuperBox&lt;/a&gt;
			</pre>
			Definiendo solo anchura:
			<pre>
				&lt;a href="http://example.com/picture.png" rel="superbox[image][500x]"&gt;SuperBox&lt;/a&gt;
			</pre>
			</p>
			<h3>Modo Galería</h3>
			<p>El primer parametro será <code>gallery</code> y el segundo el nombre de la galeria. Todos los links que tengan ese nombre de galería serán mostrados.
			<pre>
				&lt;a href="http://example.com/picture.png" rel="superbox[gallery][my_gallery]"&gt;SuperBox&lt;/a&gt;
			</pre>
			</p>
			<h3>Modo Iframe</h3>
			<a href="http://www.google.com/" rel="superbox[iframe][700x500]" class="bt">Ejemplo de Iframe</a>
			<p>Genera una ventana con el contenido del iframe
			<pre>
				&lt;a href="http://example.com/iframe.html" rel="superbox[iframe][700x500]">Iframe&lt;/a&gt;
			</pre>
			</p>
			<h3>Modo Contenido</h3>
			<a href="#box-content" rel="superbox[content][300x200]" class="bt">Ejemplo con contenido</a>
			<div id="box-content" class="hidden">
				<h2>Titulo de ventana emergente</h2>
				contenido de ventana emergente
			</div>
			<p>Genera una ventana con el contenido de un elemento de la página
			<pre>
				&lt;a href="#box-content" rel="superbox[content][300x200]"&gt;SuperBox&lt;/a&gt;
				&lt;div id="box-content" class="hidden"&gt;contenido de ventana emergente&lt;/div&gt;
			</pre>
			</p>
		</div>