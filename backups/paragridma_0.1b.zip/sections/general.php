		<div id="general">
			<h2>Bienvenido a ParaGRIDma</h2>
			<p>
				El ParaGRIDma puede ser de mucha utilidad para <strong>cimentar nuestros nuevos proyectos</strong>. Con él conseguimos que desde el minuto 0 <strong>que nuestra aplicación tenga un estilo y una funcionalidad básica</strong>.
			</p>
			<p>
				Tambien es útil para que todas las aplicaciones que salgan de Paradigma <strong>tengan una estructura y funcionalidad lo más similar posible</strong>. De este modo, no nos tendremos que enfrentar a los mismos problemas en cada proyecto, ganando en eficiencia.
			</p>
			<p>
				Es una <strong>primera versión beta</strong>, que según vaya siendo implantada en proyectos se ira mejorando, ampliando y ajustando a nuestras necesidades reales. Como versión beta, es fácil que surjan problemas. Rogamos que nos los hagais llegar para poder mejorar.
			</p>
			<h3>Estilo y funcionalidad</h3>
			<p>
				Por una parte con este framework <strong>queremos dotar a nuestras aplicaciones de un diseño básico</strong>, sobre el cual se crearán "temas" para adapatar este diseño básico a cada una de nuestras aplicaciones. El framework dispone de un diseño básico para:
				<ul>
					<li>Pestañas</li>
					<li>Tablas</li>
					<li>Menús de navegación y submenús</li>
					<li>Formualrios</li>
					<li>Textos, cabeceras, listas,...</li>
					<li>Links, botones</li>
					<li>...</li>
				</ul>
			</p>
			<p>
				Por otra parte se quiere <strong>dotar al framework con la funcionalida básica</strong> de una aplicación web:
				<ul>
					<li>Ordaneción y filtrado de tablas</li>
					<li>Funcionalidad de formularios: placeholder, datpickers, autofocus,...</li>
					<li>Ventanas emergentes</li>
					<li>Toogle Panel</li>
					<li>Formateo de números</li>
					<li>...</li>
				</ul>
			</p>
			<p>El famework se puede usar en los pricipales navegadores del mercado: Internet Explorer (desde la versión 6), Firefox, Chrome, Safarí y Opera. Aunque es accesible desde todos estos navegadores, su apariencia visual puede cambiar según el navegador. Esto es debido a que se está usando la potencia de alguna de las funcionalidades de CSS3 que navegadores como Internet Explorer no son capaces de renderizar (border redondeados, sombras,...). Internet Explorer 9 si que renderizará estas funcionalidades (o eso prometen).</p>
			<div class="p70 first">
				<div class="p">
					<h2>Normas sobre PESTAÑAS</h2>
					<ul>
						<li>el div contenedor debe de tener la clase: <code>tabs</code></li>
						<li>Es necesaria la libreria <code>jquery-ui</code>. <a href="http://docs.jquery.com/UI/Tabs" target="_blank">Visitar ayuda de tabs</a></li>
						<li>iniciamos las pestañas por javascript:</li>
						<pre>
							$(".tabs").tabs();
						</pre>
						<li>Las pestañas serán una lista dentro del panel <code>tabs</code> con la siguiente estructura
						</li>
						<pre>
							&lt;ul&gt;
							&nbsp;&nbsp;	&lt;li&gt;&lt;a href="#panel_id"&gt;&lt;span&gt;Nombre&lt;/span&gt;&lt;/a&gt;&lt;/li&gt;
							&nbsp;&nbsp;	&lt;li&gt;&lt;a href="#panel_id_2"&gt;&lt;span&gt;Nombre 2&lt;/span&gt;&lt;/a&gt;&lt;/li&gt;
							&lt;/ul&gt;
						</pre>
						<li>
							cada pestaña tendrá un panel asociado a través del ID
						</li>
						<pre>
							&lt;div id="panel_id"&gt;
								&nbsp;...
							&lt;/div&gt;
						</pre>
					</ul>
					<h3>Carga de Pestañas a través de Ajax</h3>
					Tambien se pueden cargar el contenido de las pestañas pa través de AJAX:
					<ul>
						<li>En este caso cambia el atributo <code>href</code> del link de la prestaña, ya que apuntará a la página destino, y no al id del panel</li>
						<pre>
							&lt;li&gt;<br/>&nbsp;&lt;a href="pagina_1.html" title="Titulo Panel Destino"&gt;&lt;span&gt;Nombre&lt;/span>&lt;/a&gt;<br/>&lt;/li&gt;
						</pre>
						<li>Nota: El atributo title se usa para que la URL de la pestaña sea "human friendly", pero no es necesaria.</li>
					</ul>
				</div>
			</div>
			<div class="p30">
				<div class="p">
					<h2>Normas sobre Números</h2>
					<ul>
						<li>Para formatear un numero ENTERO hay que darle la clase <code>formatNum</code></li>
						<li>Para formatear un numero DECIMAL hay que darle la clase <code>formatNumFloat</code></li>
						<li>Tambien serán formateados todas las celdas de tabla que tengan la clase <code>number</code> ó <code>float</code>
						
					</ul>
				</div>
			</div>
		</div>