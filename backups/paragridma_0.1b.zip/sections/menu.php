		<div id="menu">
			<h2>Menu horizontal</h2>
			<nav>
				<ul>
					<li><a href="#">Section 1</a></li>
					<li><a href="#">Section 2</a></li>
					<li><a href="#">Section 3</a></li>
				</ul>
			</nav>
			<pre>
				&lt;nav&gt;
				&nbsp;&nbsp;&lt;ul&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 1&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 2&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 3&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;	&lt;/ul&gt;
				&lt;nav&gt;
			</pre>
			
			<h2>Menu vertical</h2>
			<nav>
				<ul class="v">
					<li><a href="#">Section 1</a></li>
					<li><a href="#">Section 2</a></li>
					<li><a href="#">Section 3</a></li>
				</ul>
			</nav>
			<pre>
				&lt;nav&gt;<br/>
				&nbsp;&nbsp;&lt;ul class="v"&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 1&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 2&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Section 3&lt;/a&gt;&lt;/li&gt;
				&nbsp;&nbsp;	&lt;/ul&gt;
				&lt;nav&gt;
			</pre>
			
			<h2>Menú desplegable</h2>
			<nav class="sub">
				<ul>
					<li><a href="#">Section 1</a>
						<ul class="v">
							<li><a href="#">Sub Section 1</a></li>
							<li><a href="#">Sub Section 2</a></li>
							<li><a href="#">Sub Section 3</a></li>
						</ul>
					</li>
					<li><a href="#">Section 2 (horizontal)</a>
						<ul>
							<li><a href="#">Sub Section 1</a></li>
							<li><a href="#">Sub Section 2</a></li>
							<li><a href="#">Sub Section 3</a></li>
						</ul>
					</li>
					<li><a href="#">Section 3</a>
						<ul class="v">
							<li><a href="#">Sub Section 1</a></li>
							<li><a href="#">Sub Section 2</a></li>
							<li><a href="#">Sub Section 3</a></li>
						</ul>
					</li>
				</ul>
			</nav>
			<pre>
				&lt;li&gt;&lt;a href="#"&gt;Section 2&lt;/a&gt;<br/>
				&nbsp;&nbsp;	&lt;ul class="v"&gt;<br/>
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Sub Section 1&lt;/a&gt;&lt;/li&gt;<br/>
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Sub Section 2&lt;/a&gt;&lt;/li&gt;<br/>
				&nbsp;&nbsp;&nbsp;&nbsp;		&lt;li&gt;&lt;a href="#"&gt;Sub Section 3&lt;/a&gt;&lt;/li&gt;<br/>
				&nbsp;&nbsp;	&lt;/ul&gt;<br/>
				&lt;/li&gt;
			</pre>

		</div>