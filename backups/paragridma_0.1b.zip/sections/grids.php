			<h2>Normas sobre LAYOUT</h2>
			<p>El panel que engloba toda la pagina debe tener la clase <strong>container</strong>
			</p>
			<ul>Si queremos definir anchura a paneles lo podemos hacer de 3 formas difernetes:
				<li>Anchura por columnas</li>
				<li>Anchura por porcentajes</li>
				<li>Paneles fluidos</li>
			</ul>
			<h3>Anchura por columnas</h3>
			<div class="test_guide">
				<br/><br/>
				Prueba de division por columnas
				<br/><br/><br/>
			</div>
			<ul>
				<li>El contenido de la pagina está dividida en 12 columnas (como puedes ver en la imagen superior)</li>
				
				<li>Si queremos definir una anchura por columnas a un panel le pondremos una de las siguientes clases
					<ul>
						<li><code>g1</code>: ancho de una columna</li>
						<li><code>g2</code>: ancho de 2 columnas</li>
						<li><code>gN</code>: ancho de N columnas</li>
						<li><code>g11</code>: ancho de 11 columnas</li>
					</ul>
				</li>
				<li>
					La primera de las columnas debera tener la clase <code>first</code>, para evitar el margen izquierdo que tienen el resto de columnas por defecto.
				</li>
				<li>El panel encargado de asignar el ancho (el que lleve la clase g[1,2,...,11]) <strong>no se le debe de asignar padding, margin o bordes</strong>, ya que eso modificaría el ancho.</li>
				<li>Si queremos asignar margin, padding o bordes tendremos que "anidar" otro div con dichas caracteristicas</li>
			</ul>
			<h3>Ancho por porcentajes</h3>
			<ul>
				<li>
					Tambien podemos definir la anchura por porcentaje:</li>

				<li> Para ello añadiremos al panel una de estas clases: <code>p05</code>, <code>p10</code>, <code>p15</code>, <code>p20</code>, <code>p25</code>, <code>p30</code>, <code>p35</code>, <code>p40</code>, ..., <code>p90</code>, <code>p95</code>						
				</li>
				<li>Este sistema puede causas <strong>inconsistenacias en algunos navegadores</strong> (por ejemplo algunas versiones de Intenet Explorer), ya que si el cálculo del porcentaje en decimal, unos navegadores redondean a la baja y otros a la alta, haciendo que la suma de porcentajes de mas de 100%</li>
				<li>Por este motivo habrá que usar este sistema con cautela, o hacer que la suma de 99% (por ejemplo hacer un panel de 49% y otro de 50%)</li>
				<li>El panel encargado de asignar el ancho (el que lleve la clase p[10,20...,90]) <strong>no se le debe de asignar padding, margin o bordes</strong>, ya que eso modificaría el ancho.</li>
				<li>Si queremos asignar margin, padding o bordes tendremos que "anidar" otro div con dichas caracteristicas</li>
			</ul>
			<div class="p70">
				<div class="p b">
					70% de ancho
				</div>
			</div>
			<div class="p30">
				<div class="p b">
					30% de ancho
				</div>
			</div>
			
			
			
			<h3>Paneles Fluidos</h3>
			<p>La caracteristica de estos paneles, es que tienen <strong>una columna a la izquierda de ancho ficho + una columna fluida a la derecha</strong>.</p>
			<div class="pf pf_w3">
				<div class="pf_l">
					<div class="p b">
						Columna FIJA izquierda
					</div>
				</div>
				<div class="pf_r">
					<div class="p b">
						Columna FLUIDA derecha
					</div>
				</div>
			</div>
			<p>Para usarlo es necesario esta estrucrtura
				<pre>
					&lt;div class="pf pf_w3"&gt;
					&nbsp;&nbsp;	&lt;div class="pf_l"&gt;
					&nbsp;&nbsp;&nbsp;&nbsp;		Columna FIJA izquierda
					&nbsp;&nbsp;	&lt;/div&gt;
					&nbsp;&nbsp;	&lt;div class="pf_r"&gt;
					&nbsp;&nbsp;&nbsp;&nbsp;		Columna FLUIDA derecha
					&nbsp;&nbsp;	&lt;/div&gt;
					&lt;/div&gt;
				</pre>
			</p>
			<ul>
				<li>La clase <code>pf</code> define que es un panel fluido.</li>
				<li>La clase <code>pf_w[1,2,3,4,...,11]</code> define la ancho en columnas que va a tener la columna izquierda:
					<ul>
						<li><code>pf_w1</code>: 54px</li>
						<li><code>pf_w2</code>: 138px</li>
						<li><code>pf_w3</code>: 222px</li>
						<li><code>pf_w4</code>: 306px</li>
						<li>...</li>
						<li><code>pf_w11</code>: 894px</li>
					</ul>
				</li>
				<li>La clase <code>pf_l</code> define el contenido de la columna izquierda</li>
				<li>La clase <code>pf_r</code> define el contenido de la columna derecha</li>
			</ul>
			
