		<div id="texts">
			<div class="p50">
				<h1>Esto es un H1</h1>
				<h2>Esto es un H2</h2>
				<h3>Esto es un H3</h3>
				<h4>Esto es un H4</h4>
				<h5>Esto es un H5</h5>
				<h6>Esto es un H1</h6>
			</div>
			<div class="p50">
				<div class="p">
					<p>
						<strong>Esto es un parrafo: </strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nibh nulla, pharetra a semper et, luctus vitae arcu. Suspendisse potenti. Ut vitae commodo enim. Vivamus ut tortor ut dolor sodales auctor et nec libero. 
					</p>
					<p>
						<strong>Y esto otro parrafo</strong> Sed lorem nisi, rutrum sit amet euismod ac, dignissim et dui? Praesent imperdiet molestie dolor ut fringilla. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut eu viverra nulla. Nullam tortor turpis, mollis vitae consectetur sed, molestie vel eros! Fusce congue, libero nec dictum suscipit, orci nibh auctor odio,
					</p>
				</div>
			</div>
			<div class="p50">
				<div class="p">
					<h2>Listas</h2>
					<div class="p50">
						<ul>
							<li>Lista apartado 1</li>
							<li>Lista apartado 2</li>
							<li>Lista apartado 3</li>
							<li>Lista apartado 4</li>
						</ul>
					</div>
					<div class="p25">
						<ol>
							<li>Lista Ordenada</li>
							<li>Lista Ordenada</li>
							<li>Lista Ordenada</li>
							<li>Lista Ordenada</li>
						</ol>
					</div>
				</div>
			</div>
			<div class="p50">
				<div class="p">
					<h2>Tamaños de fuente</h2>
					<p class="f09">Texto con tamaño de fuente 9px</p>
					<p class="f10">Texto con tamaño de fuente 10px</p>
					<p class="f11">Texto con tamaño de fuente 11px</p>
					<p class="f12">Texto con tamaño de fuente 12px</p>
					<p class="f13">Texto con tamaño de fuente 13px</p>
					<p class="f14">Texto con tamaño de fuente 14px</p>
				</div>
			</div>
		</div>