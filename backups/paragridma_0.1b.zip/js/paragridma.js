$(function(){
	$(".tabs").tabs();
	
	$("#showGuides").click(function(){
		if ($(this).hasClass('show')) {
			$(".container, .g1, .g2, .g3, .g4, .g5, .g6, .g7, .g8, .g9, .g10, .g11, .g12, .p05 , .p10 , .p15 , .p20 , .p25 , .p30 , .p35 , .p40 , .p45 , .p50 , .p55 , .p60 , .p70 , .p75 , .p80 , .p85 , .p90 , .p95").removeClass('guide');
			$(this).removeClass('show');
		} else {
			
			$(".container, .g1, .g2, .g3, .g4, .g5, .g6, .g7, .g8, .g9, .g10, .g11, .g12, .p05 , .p10 , .p15 , .p20 , .p25 , .p30 , .p35 , .p40 , .p45 , .p50 , .p55 , .p60 , .p70 , .p75 , .p80 , .p85 , .p90 , .p95").addClass('guide');
			$(this).addClass('show');
		}
	});
	
	// format numbers
	$('.formatNum, tbody .number').each(function(){
		var t = $(this);
		if(!isNaN(t.html())){ t.html($().number_format(parseInt($(this).html()))); }
	});
	$('.formatNumFloat, tbody .float').each(function(){
		var t = $(this);
		if(!isNaN(t.html())){ t.html($().number_format(parseInt($(this).html()),{numberOfDecimals:2})); }
	});
	
	// substring text
	$('[class*="substring_"]').each(function(){
		var t = $(this);
		var c = t.attr('class').split(" ");
		for (var i in c) {
			if (c[i].indexOf("substring_") != -1) {
				var chars = parseInt(c[i].split("_")[1]);
				if (t.html().length > chars) {
					t.attr('title',t.html())
						.html(t.html().substring(0, chars) + "...");
				}
			}
		}
	});
	
	// toogle panels
	$('.toggle_trigger').click(function(e){
		e.preventDefault();
		var t = $(this);
		var tg_p = $(t.attr('href'));
		var txt = t.attr('rel').split("|");
		
		if (tg_p.is(':visible')){
			tg_p.slideUp("slow");
			t.html(t.html().replace(txt[1],txt[0]));
		} else {
			tg_p.slideDown("slow");
			t.html(t.html().replace(txt[0],txt[1]));
		}
	});
	
	$('input').placeholder();
	
	$('#consolePanel').live('mouseenter',function(){
		//$(this).toggleClass('move');
	
	})
})

function log(msg){
  if(typeof window.console != 'undefined' && typeof window.console.log != 'undefined'){
	console.log( msg );
  } else {
	if ($('body #consolePanel').size()) {
		var ul = $('body #consolePanel ul');
		ul.append('<li></li>');
		ul.find('li:last').text(msg).html(ul.find('li:last').html().replace(/\n/g, "<br/>"));
		
	  } else {
		$('body').append('<div id="consolePanel"><ul><li>'+ msg +'</li></ul></div>');
	  }	
  }
}


/*
function log (message) {
            //if('console' in window && 'log' in window.console)
            if (typeof window.console != 'undefined' && typeof window.console.log != 'undefined') {
                console.log(message);
            }
            else {
                // do nothing
                alert('console is not supported: ' + message);
            }
    }
*/
