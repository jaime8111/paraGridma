<?php $activePage = ""; ?>
<?php include("includes/header.php"); ?>	
<!-- container -->
<div id="home" class="container">			
	<div class="row">
		<div class="g12">
			<h2 class="h2">Welcome to ParaGRIDma v2</h2>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="g8">
			<h3 class="h3">Sections:</h3>
			<?php include("includes/menu.php"); ?>	
			
		</div>

		<div class="g4">
			<h4 class="h4">Page info</h4>
			<ul class="disc">
				<li>empty</li>
			</ul>
		</div>
	</div>
</div> <!-- container -->		
<?php include("includes/footer.php"); ?>	
