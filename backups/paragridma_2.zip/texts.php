<?php $activePage = "texts"; ?>
<?php include("includes/header.php"); ?>
<!-- container -->
<div class="container">
	<div class="row">
		<div class="g12">
			<h2 class="h2">Texts</h2>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="g8">
			<div class="row">
				<div class="g7">
					<h1 class="h1">h1. Heading 1</h1>
					<h2 class="subheader">Subheader for h1</h2>
					<h1 class="h1">Head 2 <small>with notes</small></h1>
					<h2 class="h2">h2. Heading 2</h2>
					<h3 class="subheader">Subheader for h2</h3>
					<h3 class="h3">h3. Heading 3</h3>
					<h4 class="subheader">Subheader for h3</h4>
					<h4 class="h4">h4. Heading 4</h4>
					<h5 class="subheader">Subheader for h4</h5>
					<h5 class="h5">h5. Heading 5</h5>
					<h6 class="subheader">Subheader for h5</h6>
					<h6 class="h6">h6. Heading 6</h6>
				</div>
				<div class="g5">
					<h4 class="h4">Paragraph example</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet blandit nunc ut cursus. Integer viverra blandit erat, a feugiat dolor auctor ac. Proin tincidunt pulvinar velit, a tincidunt nisi semper eu.</p>
					<p class="i">Italic Text</p>
					<p><em>&lt;em&gt;:Emphasys text</em></p>
					<p><strong>&lt;strong&gt;:Emphasys text</strong></p>
					<p class="strong">fake strong</p>
					<p class="upper">fake uppercase</p>
					<p><code>&lt;code&gt;: text</code></p>
					<pre>&lt;pre&gt;: text</pre>
					<p><a href="javascript:vodi(0)">default link</a>
					<p><a href="javascript:vodi(0)" class="u">underline link</a>
				</div>

			</div>
		</div>
		<div class="g4">
			<h4 class="h4">Page info</h4>

			<ul class="disc">
				<li>
					Empty
				</li>
			</ul>
		</div>
		<hr />
	</div>
	<div class="row">
		<div class="g8">
			<h4 class="h4">Lists</h4>
			<hr />
			<div class="row">
				<div class="g6">
					<h5 class="h5">Default List</h5>
					<ul>
					   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
					   <li>Aliquam tincidunt mauris eu risus.</li>
					   <li>Vestibulum auctor dapibus neque.</li>
					</ul>

					<h5 class="h5">Nice List</h5>
					<ul class="nice">
						<li>
							<span class="bullet"></span>
							Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
						<li>
							<span class="bullet"></span>
							Aliquam tincidunt mauris eu risus.
						</li>
					</ul>

					<h5 class="h5">Nice List - Right side</h5>
					<ul class="nice nice_right">
						<li>
							<span class="bullet"></span>
							Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
						<li>
							<span class="bullet"></span>
							Aliquam tincidunt mauris eu risus.
						</li>
					</ul>


					<h5 class="h5">List with Discs</h5>
					<ul class="disc">
					   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
					   <li>Aliquam tincidunt mauris eu risus.</li>
					</ul>

					<h5 class="h5">List with Squares</h5>
					<ul class="square">
					   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
					   <li>Aliquam tincidunt mauris eu risus.</li>
					</ul>
				</div>
				<div class="g6">
					<h5 class="h5">List with Circles</h5>
					<ul class="circle">
					   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
					   <li>Aliquam tincidunt mauris eu risus.</li>
					</ul>

					<h5 class="h5">Order List</h5>
					<ol class="circle">
					   <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
					   <li>Aliquam tincidunt mauris eu risus.</li>
					</ol>

					<h5 class="h5">Definition List</h5>
					<dl>
					  <dt>definition list dt</dt>
					  <dd>definition list dd</dd>
					  <dt>definition list dt</dt>
					  <dd>definition list dd</dd>
					</dl>
					<h5 class="h5">Horizontal list</h5>
					<ul class="circle horizontal">
					   <li>Lorem</li>
					   <li>Ispum</li>
					   <li>Aliquam</li>
					</ul>
					<h5 class="h5">Inline list</h5>
					<ul class="circle inline">
					   <li>Lorem</li>
					   <li>Ispum</li>
					   <li>Aliquam</li>
					</ul>
				</div>
			</div>

		</div>
		<div class="g4">
			<h4 class="h4">Page info</h4>

			<ul class="disc">
				<li>
					Empty
				</li>
			</ul>
		</div>
	</div>
	<div class="row">
		<div class="g8">
			<h4 class="h4">Internacionalización</h4>

			<script type="text/javascript">
				$(function(){
					$.localise('paragridma', { language: 'es' , path: 'js/locale/'});
					alert(locale_test);
				});
			</script>
		</div>
		<div class="g4">
			<ul class="disc">
				<li>
					Se puede tener el texto internacionalizado por Javascript, y traducirlo cuando se quiera.
				</li>
				<li>
					Esto lo hacemos con el plugin <a href="http://keith-wood.name/localisation.html">jQuery Localisation</a>
				</li>
				<li>
					Pasos a seguir:
					<ul>
						<li>Incluye jQuery</li>
						<li>Incluye el plugin jquery.localisation.min.js</li>
						<li>Importa tu fichero js con los textos</li>
						<li>Utilizalo: $.localise('mypackage');</li>
						<li></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div><!-- container -->
<?php include("includes/footer.php"); ?>