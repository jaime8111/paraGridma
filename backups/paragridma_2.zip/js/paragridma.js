$(document).ready(function() {
	/*
	$(window).resize(function() {
		console.log($(window).width());
	});
	*/

	/*= DIALOG --------------------------------- */
	/* Remove if you don't need :) */
	$('.openDialog').click(function(e){
        e.preventDefault();
        var panel = $(this).attr('href');

        doDialog(panel, true);
    });
	/* end of dialog */
	
	
	// close msg panels
	$('.msg .close').live('click',function(e){
		e.preventDefault();
		var p = $(this).parents('.msg');
		hideMsg(p);
	});
	
	/* TABS --------------------------------- */
	/* Remove if you don't need :) */
	
	var tabs = $('dl.tabs');
		tabsContent = $('ul.tabs-content')
	
	tabs.each(function(i) {
		//Get all tabs
		var tab = $(this).children('dd').children('a');
		tab.click(function(e) {
			
			//Get Location of tab's content
			var contentLocation = $(this).attr("href")
			contentLocation = contentLocation + "Tab";
			
			//Let go if not a hashed one
			if(contentLocation.charAt(0)=="#") {
			
				e.preventDefault();
			
				//Make Tab Active
				tab.removeClass('active');
				$(this).addClass('active');
				
				//Show Tab Content
				$(contentLocation).parent('.tabs-content').children('li').css({"display":"none"});
				$(contentLocation).css({"display":"block"});
				
			} 
		});
	});
}); // end of document ready 


/*= DIALOG --------------------------------- */
/* Remove if you don't need :) */
function doDialog(panel, modal, width) {
	// set dialog width
	if ($(panel).attr('data-dialog_width')) { width = $(panel).attr('data-dialog_width'); }

	if (width > $(window).width()) { width = $(window).width() - 80; }
	
	$(panel).dialog({
	  modal: modal,
	  width: width,
	  open: function(event, ui) {
		var d = $(this).parent('.ui-dialog');
		if (d.size()) {
			d.append('<div class="dialogWrap" id="dialogWrap_'+$(this).attr('id')+'"/>')
				.find('.ui-dialog-titlebar, .ui-dialog-content').appendTo("#dialogWrap_"+$(this).attr('id'));
				
			//d.find('.ui-dialog-content').append('<div class="cb">XXXXXXXXXXXX</div>');

			setTimeout(function() {
				$(panel).find('input, select, textarea').first().focus();
			},150);
		}
	  }
  });
  $(panel).find('.closeDialog').click(function(e){
	  e.preventDefault();
	  $(panel).dialog("close");
  });
};
/* end of dialog */

/*= BLOCK MESSAGES --------------------------------- */
/* Remove if you don't need :) */
function showMsg(id, size, type, scroll, title, content) {
	var p = $(id);
    p.hide();

	var html = "";
    if (size == 'big' || size == 'small') {
		html	+= '<div class="pf_fix hidden"></div>';
		html	+= '<div class="pf_fluid">';
		var panelClass = 'pf';
    } else if (size == 'simple') {
		html	+= '<div>';
		var panelClass = '';
	}
	
	html	+= '  <a class="close" href="#">x</a>';

    html	+= '  <p class="msg_title">' + title + '</p>';
	html	+= '  <p class="msg_content">' + content + '</p>';
	html	+= '</div>';

	p.attr('class','msg msg_' + type + ' msg_' +  size + ' ' + panelClass)
		.html(html)
		.slideDown(500,function(){
            p.find(".pf_fix").fadeIn("slow");
        });
    if (scroll == '1') {
        var p_pos = p.offset().top - 20;

        $('html,body').animate({scrollTop:p_pos},1000);
    }
}

function hideMsg(p){
    p.find(".pf_fix").fadeOut(300,function(){
        p.fadeOut();
    })
}


/* end of block messages */


/*= TOOLTIPS --------------------------------- */
/* Remove it if you don't need :) */
    $("[title]").each(function(){
        if (!$(this).hasClass('tt_raw')) {
            // set tooltip width
            var tt_width = $(this).attr('data-tooltip_width');
                if (!tt_width) { tt_width = ''; }
                else { tt_width = "width:" + $(this).attr('data-tooltip_width') + "px"; }

            $(this).tooltip({
                effect: 'slide',
                offset: [10,0],
                layout: '<div style="'+tt_width+'"><div class="arrow"/></div>'
              })
              .dynamic({ bottom: { direction: 'down', bounce: true } }); // add dynamic plugin with optional configuration for bottom edge
        }
    });

    // create tooltip html structure before it is show
    $(".tooltipHtml").each(function(){
        var tt = $(this).next('.tooltip');
        tt.wrapInner('<div class="tooltip_content"></div>')
             .prepend('<div class="arrow" />');

      // if is a tooltip_onStart add a close button
      if ($(this).hasClass('tooltip_onStart')) {
		  tt.find('.tooltip_content').addClass('tooltip_content_onStart').prepend('<a class="close" href="#">x</a>');
      }
    });

    $(".tooltipHtml").not(".tooltip_onStart").tooltip({
        effect: 'slide',
        offset: [10,0],
        relative: true
      })
      .dynamic({ bottom: { direction: 'down', bounce: true } });

    // tooltips that will be showed on document ready.
    $(".tooltip_onStart").each(function(){
        var tt = $(this);
        tt.tooltip({
            effect: 'slide',
            offset: [10,0],
            relative: true,
            events: {
                def: ",click", // never show, hide on click
                tooltip: "mouseenter" // show on tooltip mouseenter, never hide
            }
          });
        tt.tooltip().show();
        tt.next('.tooltip').find('.close').click(function(e){
			e.preventDefault();
            tt.tooltip().hide();
        });
    })

/* end of Tooltips */	