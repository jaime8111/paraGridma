
	
	
	<!-- Included JS Files -->
	
	<!-- Those files for IE must be pack (minify & unify) in one only file on PRODUCTION -->
	<!--[if lte IE 9]>
		<script src="js/packs/modernizr-2.0.6.min.js"></script>
		<script src="js/packs/jquery.placeholder.js"></script>
		<script src="js/packs/autofocus.js"></script>
	<![endif]-->
	<script src="js/packs/jquery-ui.min.js"></script>
	<script src="js/packs/jquery.tools.tooltip.min.js"></script>
	
	<script src="js/packs/localisation/jquery.localisation.min.js"></script>
	<script src="js/packs/ui-multiselect.js"></script>
	<script src="js/packs/ui-autocompleteCombo.js"></script>
	
	<script src="js/paragridma.js"></script>
</body>
</html>