<!DOCTYPE html>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
	<meta charset="utf-8" />
	
	<!-- Set the viewport width to device width for mobile -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	<title>ParaGRIDma v2</title>
	<link rel="shortcut icon" href="images/favicon.ico" />
	
	<!-- Included CSS Files -->
	<link rel="stylesheet" href="css/paragridma.css">
	<link rel="stylesheet" href="css/theme.css">

	<!--[if lte IE 9]>
		<link rel="stylesheet" href="css/ie.css">
	<![endif]-->
	<!--[if lte IE 8]>
		<link rel="stylesheet" href="css/ie8.css">
	<![endif]-->
	<!--[if lte IE 7]>
		<link rel="stylesheet" href="css/ie7.css">
	<![endif]-->

	
	<script src="js/jquery.js"></script>

	<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script> -->
	
	<!-- IE Fix for HTML5 Tags -->
	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

</head>
<body>
	<div id="header" class="container">
		<div class="row">
			<div class="g12">
				<div class="pf pf_g250">
					<div class="pf_fix">
						<a href="index.php"><img src="images/paragridma.png" /></a>
					</div>
					<div class="pf_fluid">
						<h1>
							Nuestro framework CSS + Javascript
						</h1>
					</div>
				</div>
				<?php include("includes/menu.php"); ?>
				<hr />
			</div>
		</div>
		
	</div>

	