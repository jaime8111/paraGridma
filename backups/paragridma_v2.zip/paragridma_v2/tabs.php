<?php $activePage = "tabs"; ?>
<?php include("includes/header.php"); ?>	
<!-- container -->
<div class="container">			
	<div class="row">
		<div class="g12">
			<h2 class="h2">Tabs</h2>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="g8">
			<dl class="tabs">
				<dd><a href="#simple1" class="active">Simple Tab 1</a></dd>
				<dd><a href="#simple2">Simple Tab 2</a></dd>
				<dd><a href="#simple3">Simple Tab 3</a></dd>
			</dl>
			
			<ul class="tabs-content">
				<li class="active" id="simple1">This is simple tab 1's content. Pretty neat, huh?</li>
				<li id="simple2">This is simple tab 2's content. Now you see it!</li>
				<li id="simple3">This is simple tab 3's content. It's, you know...okay.</li>
			</ul>
		</div>

		<div class="g4">
			<h4 class="h4"Page info</h4>
			
			<ul class="disc">
				<li>
					Empty
				</li>
			</ul>
		</div>
	</div>
</div><!-- container -->		
<?php include("includes/footer.php"); ?>	