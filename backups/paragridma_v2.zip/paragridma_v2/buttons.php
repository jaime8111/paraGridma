<?php $activePage = "buttons"; ?>
<?php include("includes/header.php"); ?>
<!-- container -->
<div class="container">
	<div class="row">
		<div class="g12">
			<h2 class="h2">Buttons</h2>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="g8">
			<h4 class="h4">Links as buttons</h4>
			<a href="javascript:void(0)" class="bt bt_small">Small Link Button</a>
			<br />
			<a href="javascript:void(0)" class="bt">Medium Link Button</a>
			<br />
			<a href="javascript:void(0)" class="bt bt_large">Large Link Button</a>

			<p class="bt_group">
				<a href="javascript:void(0)" class="bt">Main Action Link Button</a>
				<a href="javascript:void(0)" class="bt bt_sub">Secundary Link Button</a>
			</p>

			<p class="bt_group">
				<a href="javascript:void(0)" class="bt disabled">Disable Main Action Link Button</a>
				<a href="javascript:void(0)" class="bt bt_sub disabled">Disable Secundary Link Button</a>
			</p>

			<p class="bt_group">
				<a href="javascript:void(0)" class="bt">Default</a>
				<a href="javascript:void(0)" class="bt bt_sub">Subordinate</a>
				<a href="javascript:void(0)" class="bt bt_success">Success</a>
				<a href="javascript:void(0)" class="bt bt_danger">Danger</a>
			</p>

			<h4 class="h4">Links with icon as buttons</h4>
			<a href="javascript:void(0)" class="bt bt_small bt_icon">
				<em class="icon"></em>
				Small Link Button
			</a>
			<br />
			<a href="javascript:void(0)" class="bt bt_icon">
				<em class="icon"></em>
				Medium Link Button
			</a>
			<br />
			<a href="javascript:void(0)" class="bt bt_large bt_icon">
				<em class="icon"></em>
				Large Link Button
			</a>


			<h4 class="h4">&lt;button&gt; as buttons</h4>
			<button class="bt bt_small">Small &lt;button&gt; Button</button>
			<br />
			<button class="bt">Medium &lt;button&gt; Button</button>
			<br />
			<button class="bt bt_large">Large &lt;button&gt; Button</button>

			<p class="bt_group">
				<button class="bt">Main Action &lt;button&gt; Button</button>
				<button class="bt bt_sub">Main Action &lt;button&gt; Button</button>
			</p>

			<p class="bt_group">
				<button class="bt disabled" disabled="disabled">Disable Main Action Button</button>
				<button class="bt bt_sub disabled" disabled="disabled">Disable Main Action Button</button>
			</p>

			<p class="bt_group">
				<button class="bt">Default</button>
				<button class="bt bt_sub">Subordinate</button>
				<button class="bt bt_success">Success</button>
				<button class="bt bt_danger">Danger</button>
			</p>

			<h4 class="h4">Inputs as buttons</h4>
			<input type="submit" class="bt bt_small" value="Input Small Button" />
			<br/>
			<input type="submit" class="bt" value="Input Medium Button" />
			<br/>
			<input type="submit" class="bt bt_large" value="Input Large Button" />

			<p>
				<input type="submit" class="bt" value="Main Action Input Button" />
				<input type="submit" class="bt bt_sub" value="Main Action Input Button" />
			</p>

			<p>
				<input type="submit" class="bt disabled" value="Disable Main Action Input Button" disabled="disabled" />
				<input type="submit" class="bt bt_sub disabled" value="Disable Main Action Input Button" disabled="disabled" />
			</p>

			<p class="bt_group">
				<input type="submit" class="bt" value="Default" />
				<input type="submit" class="bt bt_sub" value="Subordinate" />
				<input type="submit" class="bt bt_success" value="Success" />
				<input type="submit" class="bt bt_danger" value="Danger" />
			</p>

			<h4 class="h4">Inputs with append buttons</h4>
			<div class="fg">
				<label>Default Input with append button</label>
				<div class="inputWithButton inputWithButton_200">
					<div class="inputWrap">
						<input type="text" class="text" />
					</div>
					<div class="btWrap">
						<a href="javascript:void(0)" class="bt bt_small">Button</a>
					</div>
				</div>
			</div>


		</div>

		<div class="g4">
			<h4 class="h4">Buttons info</h4>

			<ul class="disc">
				<li>
					Empty
				</li>
			</ul>
		</div>
	</div>
</div> <!-- container -->
<?php include("includes/footer.php"); ?>