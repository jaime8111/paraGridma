<?php $activePage = "tables"; ?>
<?php include("includes/header.php"); ?>	
<!-- container -->
<div class="container">			
	<div class="row">
		<div class="g12">
			<h2 class="h2">Tables</h2>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="g8">
			<table>
				<thead>
				  <tr>
					<th>#</th>
					<th>Lorem ipsum</th>
					<th>dolor sit</th>
					<th>Aliquam </th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>1</td>
					<td>Vestibulum</td>
					<td>auctor</td>
					<td>dapibus</td>
				  </tr>
				  <tr>
					<td>2</td>
					<td>faucibus</td>
					<td>tortor</td>
					<td>eros</td>
				  </tr>
				  <tr>
					<td>3</td>
					<td>Morbi in sem quis dui placerat ornare. Pellentesque odio nisi, euismod in, pharetra a, ultricies in, diam. Sed arcu. Cras consequat.</td>
					<td>Pellentesque</td>
					<td>eleifend</td>
				  </tr>
				</tbody>
			</table>
		</div>

		<div class="g4">
			<h4 class="h4"Page info</h4>
			
			<ul class="disc">
				<li>
					Empty
				</li>
			</ul>
		</div>
	</div>
</div><!-- container -->		
<?php include("includes/footer.php"); ?>	