<?php $activePage = "forms"; ?>
<?php include("includes/header.php"); ?>	
<!-- container -->
<div class="container">		
	<div class="row">
		<div class="g12">
			<h2 class="h2">Forms</h2>
			<hr />
		</div>
	</div>
	<div class="row">
		<div class="g8">
			<h4 class="h4"><a name="autocomplete"></a>Autocomplete</h4>
			
			<script type="text/javascript">
				$(function(){
					$( ".combobox" ).combobox();
				});
			</script>
			
			<select class="combobox">
				<option value="">Select one...</option>
				<option value="ActionScript">ActionScript</option>
				<option value="AppleScript">AppleScript</option>
				<option value="Asp">Asp</option>
				<option value="BASIC">BASIC</option>
				<option value="C">C</option>
				<option value="C++">C++</option>
				<option value="Clojure">Clojure</option>
				<option value="COBOL">COBOL</option>
				<option value="ColdFusion">ColdFusion</option>
				<option value="Erlang">Erlang</option>
				<option value="Fortran">Fortran</option>
				<option value="Groovy">Groovy</option>
				<option value="Haskell">Haskell</option>
				<option value="Java">Java</option>
				<option value="JavaScript">JavaScript</option>
				<option value="Lisp">Lisp</option>
				<option value="Perl">Perl</option>
				<option value="PHP">PHP</option>
				<option value="Python">Python</option>
				<option value="Ruby">Ruby</option>
				<option value="Scala">Scala</option>
				<option value="Scheme">Scheme</option>
			</select>
		</div>
		<div class="g4">
			<h4 class="h4">Autocomplete combo</h4>
			<ul class="disc">
				<li>
				</li>
			</ul>
		</div>
	</div>
	<div class="row">
		<div class="g8">
			<h3 class="h3">Inputs</h3>
			<div class="fg">
				<label>Default Text Input</label>
				<input type="text" class="text"/>
			</div>
			<div class="fg">
				<label>Input with autofocus</label>
				<input type="text" class="text" autofocus/>
			</div>
			<div class="fg">
				<label>Label</label>
				<input type="text" class="text small" />
			</div>
			<div class="fg">
				<label>Label</label>
				<input type="text" class="text large" />
				<small>description of the field</small>
			</div>
			<div class="fg fg_error">
				<label>Label with error</label>
				<input type="text" class="text large" />
				<small>description of the field</small>
			</div>
			<div class="fg">
				<label>Label</label>
				<input type="text" class="text large" placeholder="with placeholder" />
			</div>
			<div class="fg">
				<label>Label with password</label>
				<input type="password" class="text large" value="1234"/>
			</div>
			<div class="fg">
				<label>Disabled Input</label>
				<input type="text" class="text disabled" disabled="disabled"/>
			</div>
			<div class="fh">
				<h4 class="h4">Inline/Horizontal Inputs</h4>
				<div class="fg">
					<label>inline Input</label>
					<input type="text" class="text small"/>
				</div>
				<div class="fg">
					<label>inline Input</label>
					<input type="text" class="text small"/>
				</div>
				<div class="fg">
					<label>inline Input</label>
					<input type="text" class="text small"/>
				</div>
			</div>
		</div>
		<div class="g4">
			<h4 class="h4">Inputs info</h4>
			
			<ul class="disc">
				<li>
					All form components must be inside a <code>&lt;div class="fg"&gt;</code>
				</li>
				<li>
					Default state is: Label above form field (like a block element). This improve form's readibility.
				</li>
				<li>
					All text input must have the <code>class="text"</code>
				</li>
				<li>
					But we can display <strong>inline forms</strong> items wrapping form elements with the  <code>class="fh"</code>
				</li>
				<li>
					<strong>Size class</strong>: Input can have one of those classes: <code>large</code> or <code>small</code>
				</li>
				<li>
					We can insert <strong>field annotations</strong> width:
					<code>&lt;small&gt;notes&lt;/small&gt;</code>
				</li>
				<li>
					To show an <strong>error in an input</strong> we must add <code>class="fg_error"</code> to the wrapper element.
				</li>
				<li>
					If we want that the field show a placeholder text we must add attribute <code>placeholder="text"</code> in the input
				</li>
			</ul>
		</div>	
	</div>
	<div class="row">
		<div class="g8">		
			<h3 class="h3">Selects / Dropdown</h3>
			<div class="fg">
				<label>Default Combo</label>
				<select>
					<option>empty</option>
				</select>
			</div>
			<div class="fg">
				<label>Small Combo</label>
				<select class="small">
					<option>empty</option>
				</select>
			</div>
			<div class="fg">
				<label>Large Combo</label>
				<select class="large">
					<option>empty</option>
				</select>
				<small>description of the field</small>
			</div>
			<div class="fg fg_error">
				<label>Default Combo</label>
				<select>
					<option>empty</option>
				</select>
			</div>
			<div class="fg">
				<label>Disabled Combo</label>
				<select class="disabled" disabled="disabled">
					<option>empty</option>
				</select>
			</div>
			<div class="fh">
				<div class="fg">
					<label>Inline Combo</label>
					<select class="small">
						<option>empty</option>
					</select>
				</div>
				<div class="fg">
					<label>Inline Combo</label>
					<select class="small">
						<option>empty</option>
					</select>
				</div>
				<div class="fg">
					<label>Inline Combo</label>
					<select class="small">
						<option>empty</option>
					</select>
				</div>
			</div>
			
			
			<h3 class="h3">Textarea</h3>
			<div class="fg">
				<label>Default Textarea</label>
				<textarea></textarea>
			</div>
			<div class="fg">
				<label>Large Textarea</label>
				<textarea class="large"></textarea>
			</div>
			<div class="fg fg_error">
				<label>Default Textarea</label>
				<textarea></textarea>
				<small>description of the field</small>
			</div>
			<div class="fg">
				<label>Disabled Textarea</label>
				<textarea disabled="disabled" class="disabled"></textarea>
			</div>
		</div>
		<div class="g4">
			<h4 class="h4">Dropdown & Text area info</h4>
			
			<ul class="disc">
				<li>
					All form components must be inside a <code>&lt;div class="fg"&gt;</code>
				</li>
				<li>
					Default state is: Label above form field (like a block element). This improve form's readibility.
				</li>
				<li>
					<strong>Size class</strong>: Combos can have one of those classes: <code>large</code> or <code>small</code>
				</li>
				<li>
					We can display <strong>inline forms</strong> items wrapping form elements with the  <code>class="fh"</code>
				</li>
				<li>
					We can insert <strong>field annotations</strong> width:
					<code>&lt;small&gt;notes&lt;/small&gt;</code>
				</li>
				<li>
					To show an <strong>error in an input</strong> we must add <code>class="fg_error"</code> to the wrapper element.
				</li>
			</ul>
		</div>	
	</div>
	<div class="row">
		<div class="g4">
			<h3 class="h3">Checkbox</h3>
			<div class="fg checkboxGroup">
				<label for="test_C_4">Checkbox with label on the left side</label>
				<input type="checkbox" id="test_C_4" class="checkbox" />
			</div>
			<div class="fg checkboxGroup">
				<input type="checkbox" id="test_C_5" class="checkbox" />
				<label for="test_C_5">Checkbox with label on the right side</label>
			</div>
			<div class="fg checkboxGroup">
				<label>Checkbox Group</label>
				<div class="options">	
					<div class="option">
						<input type="checkbox" id="test_C_1" class="checkbox">
						<label for="test_C_1">option 1</label>	
					</div>
					<div class="option">
						<input type="checkbox" id="test_C_2" class="checkbox">
						<label for="test_C_2">option 2</label>		
					</div>
					<div class="option">
						<input type="checkbox" id="test_C_3" class="checkbox">
						<label for="test_C_3">option 3</label>
					</div>
				</div>
			</div>
			<div class="fh">
				<div class="fg checkboxGroup">
					<label>Inline checkboxs</label>
					<div class="options">	
						<div class="option">
							<input type="checkbox" id="test_D_1" class="checkbox">
							<label for="test_D_1">opt 1</label>	
						</div>
						<div class="option">
							<input type="checkbox" id="test_D_2" class="checkbox">
							<label for="test_D_2">opt 2</label>		
						</div>
						<div class="option">
							<input type="checkbox" id="test_D_3" class="checkbox">
							<label for="test_D_3">opt 3</label>
						</div>
					</div>
				</div>
				<div class="fg fg_error checkboxGroup">
					<label>Inline checkboxs</label>
					<div class="options">	
						<div class="option">
							<input type="checkbox" id="test_D_1" class="checkbox">
							<label for="test_D_1">opt 1</label>	
						</div>
						<div class="option">
							<input type="checkbox" id="test_D_2" class="checkbox">
							<label for="test_D_2">opt 2</label>		
						</div>
						<div class="option">
							<input type="checkbox" id="test_D_3" class="checkbox">
							<label for="test_D_3">opt 3</label>
						</div>
					</div>
				</div>
			</div>
		</div>	
		<div class="g4">
			<h3 class="h3">Radio</h3>
			<div class="fg radioGroup">
				<label>Radio Group</label>
				<div class="options">	
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_1" class="radio">
						<label for="test_1">option 1</label>	
					</div>
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_2" class="radio">
						<label for="test_2">option 2</label>		
					</div>
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_3" class="radio">
						<label for="test_3">option 3</label>
					</div>
				</div>
			</div>
			<div class="fg fg_error radioGroup">
				<label>Radio Group</label>
				<div class="options">	
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_1" class="radio">
						<label for="test_1">option 1</label>	
					</div>
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_2" class="radio">
						<label for="test_2">option 2</label>		
					</div>
					<div class="option">
						<input type="radio" value="valor del input" name="name" id="test_3" class="radio">
						<label for="test_3">option 3</label>
					</div>
				</div>
			</div>
			<div class="fh">
				<div class="fg radioGroup">
					<label>Inline Radio Group</label>
					<div class="options">	
						<div class="option">
							<input type="radio" value="valor del input" name="name" id="test_E_1" class="radio">
							<label for="test_E_1">op.1</label>	
						</div>
						<div class="option">
							<input type="radio" value="valor del input" name="name" id="test_E_2" class="radio">
							<label for="test_E_2">op.2</label>		
						</div>
						<div class="option">
							<input type="radio" value="valor del input" name="name" id="test_E_3" class="radio">
							<label for="test_E_3">op.3</label>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="g4">
			<h4 class="h4">Checkbox & Radio info</h4>
			
			<ul class="disc">
				<li>
					This is a checkbox structure:
					<pre>&lt;div class="fg checkboxGroup"&gt;
  &lt;label>Checkbox Group&lt;/label&gt;
  &lt;div class="options"&gt;
    &lt;div class="option"&gt;
      &lt;input type="checkbox" id="name" class="checkbox"&gt;
      &lt;label for="name">option 1&lt;/label&gt;
    &lt;/div>
    &lt;div class="option"&gt;
      &lt;input type="checkbox" id="name" class="checkbox"&gt;
      &lt;label for="name">option 2&lt;/label&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;</pre>
				</li>
				<li>
					This is a Radiogroup structure:
					<pre>&lt;div class="fg radioGroup"&gt;
  &lt;label>Radio Group&lt;/label&gt;
  &lt;div class="options"&gt;
    &lt;div class="option"&gt;
      &lt;input type="radio" id="name" class="radio"&gt;
      &lt;label for="name">option 1&lt;/label&gt;
    &lt;/div>
    &lt;div class="option"&gt;
      &lt;input type="radio" id="name" class="radio"&gt;
      &lt;label for="name">option 2&lt;/label&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;</pre>
				</li>
				<li>
					To show <strong>inline checkbox or radios</strong> you must wrap your form component in a <code>class="fh"</code>
				</li>
			</ul>
		</div>	
	</div>
	<div class="row">
		<div class="g8">
			<h4 class="h4"><a name="multiselect"></a>Componente Multiselección</h4>
			
			<script type="text/javascript">
				$(function(){
					$.localise('multiselect', { language: 'es' , path: 'js/locale/'});
					$(".multiselect").multiselect({
						searchPlaceHolder_txt: 'Filtrar paises',
						itemsCount_txt: 'paises seleccionados:'
					});
				});
			</script>
			<form>
				<select id="countries" class="multiselect" multiple="multiple" name="countries[]">
					<option value="AFG">Afghanistan</option>
					<option value="ALB">Albania</option>
					<option value="DZA">Algeria</option>
					<option value="AND">Andorra</option>
					<option value="ARG">Argentina</option>
					<option value="ARM">Armenia</option>
					<option value="ABW">Aruba</option>
					<option value="AUS">Australia</option>
					<option value="AUT" selected="selected">Austria</option>

					<option value="AZE">Azerbaijan</option>
					<option value="BGD">Bangladesh</option>
					<option value="BLR">Belarus</option>
					<option value="BEL">Belgium</option>
					<option value="BIH">Bosnia and Herzegovina</option>
					<option value="BRA">Brazil</option>
					<option value="BRN">Brunei</option>
					<option value="BGR">Bulgaria</option>
					<option value="CAN">Canada</option>

					<option value="CHN">China</option>
					<option value="COL">Colombia</option>
					<option value="HRV">Croatia</option>
					<option value="CYP">Cyprus</option>
					<option value="CZE">Czech Republic</option>
					<option value="DNK">Denmark</option>
					<option value="EGY">Egypt</option>
					<option value="EST">Estonia</option>
					<option value="FIN">Finland</option>

					<option value="FRA">France</option>
					<option value="GEO">Georgia</option>
					<option value="DEU" selected="selected">Germany</option>
					<option value="GRC">Greece</option>
					<option value="HKG">Hong Kong</option>
					<option value="HUN">Hungary</option>
					<option value="ISL">Iceland</option>
					<option value="IND">India</option>
					<option value="IDN">Indonesia</option>

					<option value="IRN">Iran</option>
					<option value="IRL">Ireland</option>
					<option value="ISR">Israel</option>
					<option value="ITA">Italy</option>
					<option value="JPN">Japan</option>
					<option value="JOR">Jordan</option>
					<option value="KAZ">Kazakhstan</option>
					<option value="KWT">Kuwait</option>
					<option value="KGZ">Kyrgyzstan</option>

					<option value="LVA">Latvia</option>
					<option value="LBN">Lebanon</option>
					<option value="LIE">Liechtenstein</option>
					<option value="LTU">Lithuania</option>
					<option value="LUX">Luxembourg</option>
					<option value="MAC">Macau</option>
					<option value="MKD">Macedonia</option>
					<option value="MYS">Malaysia</option>
					<option value="MLT">Malta</option>

					<option value="MEX">Mexico</option>
					<option value="MDA">Moldova</option>
					<option value="MNG">Mongolia</option>
					<option value="NLD" selected="selected">Netherlands</option>
					<option value="NZL">New Zealand</option>
					<option value="NGA">Nigeria</option>
					<option value="NOR">Norway</option>
					<option value="PER">Peru</option>
					<option value="PHL">Philippines</option>

					<option value="POL">Poland</option>
					<option value="PRT">Portugal</option>
					<option value="QAT">Qatar</option>
					<option value="ROU">Romania</option>
					<option value="RUS">Russia</option>
					<option value="SMR">San Marino</option>
					<option value="SAU">Saudi Arabia</option>
					<option value="CSG">Serbia and Montenegro</option>
					<option value="SGP">Singapore</option>

					<option value="SVK">Slovakia</option>
					<option value="SVN">Slovenia</option>
					<option value="ZAF">South Africa</option>
					<option value="KOR">South Korea</option>
					<option value="ESP">Spain</option>
					<option value="LKA">Sri Lanka</option>
					<option value="SWE">Sweden</option>
					<option value="CHE">Switzerland</option>
					<option value="SYR">Syria</option>

					<option value="TWN">Taiwan</option>
					<option value="TJK">Tajikistan</option>
					<option value="THA">Thailand</option>
					<option value="TUR">Turkey</option>
					<option value="TKM">Turkmenistan</option>
					<option value="UKR">Ukraine</option>
					<option value="ARE">United Arab Emirates</option>
					<option value="GBR">United Kingdom</option>
					<option value="USA" selected="selected">United States</option>

					<option value="UZB">Uzbekistan</option>
					<option value="VAT">Vatican City</option>
					<option value="VNM">Vietnam</option>
				</select>
			</form>	
		</div>
		<div class="g4">
			<h4 class="h4">Multiselección Info</h4>
			<ul class="disc">
				<li>
					Dependendencia de jquery.localisation.min.js (documentado en la sección de textos)
				</li>
				<li>
					Creación: <code>$(".multiselect").multiselect();</code>
				</li>
				<li>
					El combo utiliado deberá tener la propiedad <code>multiple="multiple"</code>
				</li>
			</ul>
		</div>
	</div>
	
</div> <!-- container -->		
<?php include("includes/footer.php"); ?>	